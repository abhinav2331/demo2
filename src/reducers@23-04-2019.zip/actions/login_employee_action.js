import axios from "axios";
import History from '../constant/history.js';

//import { LOGIN_EMPLOYEE } from "./types";
import { AUTH_URI } from "../constant/uri.constants";
import { AUTH_USER, UNAUTH_USER, AUTH_ERROR, FETCH_FEATURE } from "../constant/auth.constants";

//const loginEmployeeAsync = (logindetail) => {    
//    return {
//        type: LOGIN_EMPLOYEE,
//        payload: {
//            email: logindetail.email,
//            password: logindetail.password            
//        }
//    }
//}


//const loginEmployee = ({ email, password }) => {
//    return dispatch => {
//        debugger;
//        return axios.post(`${AUTH_URI}/users/login`, { "user": { email, password } })
//            .then((response) => {                
//                console.log(response.data.user.token);
//                console.log(response.data);
//                localStorage.setItem("token", response.data.user.token);
//                dispatch(loginEmployeeAsync({ email, password }));
//            })
//            .catch((error) => {
//                console.log(error);
//                throw (error);
//            });
//    }
//}

export const loginEmployee = ({ email, password }) => {
    return (dispatch) => {
        // submit email/password to the server
        axios.post(`${AUTH_URI}/users/login`, { "user": { email, password } })
            .then(response => {
                // if request is good...
                // - update state to indicate user is authenticated
                dispatch({ type: AUTH_USER });

                // - save the jwt token
                localStorage.setItem('token', response.data.user.token);

                // - redirect to the route '/feature'
                History.push('/');

            }).catch(() => {
                // if request is bad...
                // - show an error to the user
                dispatch(authError('Bad Login Info'));
            });
    };
};

export const authError = (error) => {
    return {
        type: AUTH_ERROR,
        payload: error
    };
};


//export default loginEmployee;

