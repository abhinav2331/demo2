import axios from "axios";
import { GET_ALL_ARTICLES } from './types';

import { AUTH_URI } from "../app.uri";


const getAllArticles = () => {
    //debugger;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles`)
            .then(response => {
                console.log(response.data.articles);
                dispatch({
                    type: GET_ALL_ARTICLES,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);

            });
    };
};

export default getAllArticles;