import axios from "axios";
import History from '../history.js';
import { AUTH_USER, UNAUTH_USER, AUTH_ERROR, FETCH_CURRENT_EMPLOYEE, EDIT_CURRENT_EMPLOYEE, ADD_NEW_POST } from './types';
import { AUTH_URI } from "../app.uri";



export const authError = (error) => {
    return {
        type: AUTH_ERROR,
        payload: error
    };
};


export const loginEmployee = ({ email, password }) => {
    return (dispatch) => {
        // submit email/password to the server
        //debugger;
        axios.post(`${AUTH_URI}/users/login`, { "user": { email, password } })        
            .then(response => {                
                // if request is good...
                // - update state to indicate user is authenticated
                dispatch({ type: AUTH_USER });
                console.log(response.data);
                // - save the jwt token
                localStorage.setItem('token', response.data.user.token);
                localStorage.setItem('authenticated',  true);
                //localStorage.setItem('crntuser', JSON.stringify(response.data.user));
                console.log(response.data.user.token);

                // - redirect to the route '/feature'
                History.push('/dashboard');

            }).catch(() => {
                // if request is bad...
                // - show an error to the user
                dispatch(authError('Bad Login Info'));
            });
    };
};


export const signoutEmployee = () => {    
    localStorage.removeItem('token');    
    History.push('/login');
    return { type: UNAUTH_USER };  
    
};

export const signupEmployee = ({ username, email, password }) => {
    return (dispatch) => {
        // submit email/password to the server
        //debugger;
        axios.post(`${AUTH_URI}/users`, { user: { username, email, password } })
            .then(response => {
                dispatch({ type: AUTH_USER });
                console.log(response);
                localStorage.setItem('token', response.data.user.token);                
                History.push('/login');
            })
            .catch(err => {
                console.log(err.response);
                console.log(err.response.data.errors);
                dispatch(authError(err.response));
            });
    };
};

export const fetchCurrentEmployee = () => {
    debugger;
    return (dispatch) => {        
        axios.get(`${AUTH_URI}/user`, { headers: { authorization: "Token "+localStorage.getItem('token') }            
        }).then(response => {
            console.log(response.data.user);
            dispatch({
                type: FETCH_CURRENT_EMPLOYEE,
                payload: response.data.user                
            });
        });
    };
};

export const editCurrentEmployee = (currentemployees) => {
    //debugger;    
    return (dispatch) => {
        axios({
            method: 'put',
            url: `${AUTH_URI}/user`,
            data: JSON.stringify(currentemployees),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: EDIT_CURRENT_EMPLOYEE });
            console.log("Plus" + response);
            }).catch(error => {
                console.log("Post Error : " + error);
        });
    }
    
};


export const addNewPost = (addPost) => {
    return (dispatch) => {        
        debugger;       
        axios({
            method: 'post',
            url: `${AUTH_URI}/articles`,
            data: JSON.stringify(addPost),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: ADD_NEW_POST });
            console.log(response.data);
        }).catch(error => {
            console.log("Post Error : " + error);
        });

    };
};





