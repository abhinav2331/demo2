import axios from "axios";
import { GET_ALL_TAGS, GET_ARTICLE_BY_TAG, GET_ARTICLE_BY_SLUG } from './types';

import { AUTH_URI } from "../app.uri";


export const getAllTags = () => {
    //debugger;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/tags`)
            .then(response => {
                console.log(response.data);
                dispatch({
                    type: GET_ALL_TAGS,
                    payload: response.data
                });
            }).catch(error => {
                console.log(error);

            });
    };
};

export const getArticleByTag = (tagList) => {
    //debugger;
    const uri_tag = tagList;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles?tag=${uri_tag}`)
            .then(response => {
                //console.log("--------");
                //console.log(response.data.articles);
                dispatch({
                    type: GET_ARTICLE_BY_TAG,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleBySlug = (clickedslug) => {
    debugger;
    const slug_uri = clickedslug;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles/${slug_uri}`)
            .then(response => {
                console.log("--------");
                console.log(response.data);
                dispatch({
                    type: GET_ARTICLE_BY_SLUG,
                    payload: response.data.article
                });
            }).catch(error => {
                console.log(error);
            });
    };
};




