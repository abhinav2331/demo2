import { GET_ARTICLE_BY_TAG, GET_ARTICLE_BY_SLUG } from '../actions/types';

const getArticleByTagReducers = (state = {}, action) => {

    switch (action.type) {       

        case GET_ARTICLE_BY_TAG:
            return { ...state, articlebytag: action.payload }

        case GET_ARTICLE_BY_SLUG:
            return { ...state, articlebyslug: action.payload }

        default:
            return state;
    }
};


export default getArticleByTagReducers;



