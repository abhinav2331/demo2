import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { fetchCurrentEmployee } from "../actions/login_employee_action";
import Editcurrentemployeemodal from "./editCurrentEmployeeModal";

class Currentemployee extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            editCurrentEmployeeModal: false,
            email: "",            
            username: "",
            bio: "",
            image: ""
        }
        this.closeEditCurrentEmployeeModal = this.closeEditCurrentEmployeeModal.bind(this);
        this.toggleEditCurrentEmployeeModal = this.toggleEditCurrentEmployeeModal.bind(this);
    }

    toggleEditCurrentEmployeeModal() {
        this.setState({            
            editCurrentEmployeeModal: !this.state.editCurrentEmployeeModal            
        });
    }

    closeEditCurrentEmployeeModal() {
        this.setState({
            editCurrentEmployeeModal: !this.state.editCurrentEmployeeModal
        })
    }

    componentWillMount() {
        this.props.fetchCurrentEmployee();
    }

    render() {
        const EmployeeAuth = this.props.EmployeeAuth;
        console.log("root:");
        //console.log(EmployeeAuth);  
        //console.log(EmployeeAuth.email); 
        return (
            <section>
                <div className="profile_section">
                    <div className="content">
                        <button onClick={() => this.toggleEditCurrentEmployeeModal()} className="btn btn-primary edit_employee">Edit</button>
                        <div className="profile_image">
                            {
                                EmployeeAuth.image == null ?
                                    <img src="http://chittagongit.com/images/dummy-icon/dummy-icon-7.jpg" alt="" />
                                    : <img src={EmployeeAuth.image} alt="" />
                            }
                        </div>
                        <div className="username">
                            {EmployeeAuth.username}
                        </div>
                        <div className="email">
                            {EmployeeAuth.email}
                        </div>
                        <p>{EmployeeAuth.bio}</p>
                    </div>
                </div>

                <Editcurrentemployeemodal
                    open={this.state.editCurrentEmployeeModal}
                    close={this.closeEditCurrentEmployeeModal}
                    id={EmployeeAuth.id}
                    email={EmployeeAuth.email}
                    username={EmployeeAuth.username}
                    bio={EmployeeAuth.bio}
                    image={EmployeeAuth.image}
            />

            </section>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth.crtemployee
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            fetchCurrentEmployee: fetchCurrentEmployee
        },
        dispatch
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(Currentemployee);
