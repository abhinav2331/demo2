export const GET_USERS_LIST = "get_users_list";
export const GET_ALL_REWARDS = "get_all_rewards";
export const GET_EMPLOYEE_LIST = "get_employee_list";
export const UPDATE_REASON = "update_reason";
export const DELETE_USER = "delete_user";
export const ADD_USER = "add_user";
export const ADD_EMPLOYEE = "add_employee";
export const EDIT_EMPLOYEE = "edit_employee";
export const DELETE_EMPLOYEE = "delete_employee";
export const EMP_ADD_RESPONSE = "emp_add_response";
export const AUTH_USER = 'auth_user';
export const UNAUTH_USER = 'unauth_user';
export const AUTH_ERROR = 'auth_error';
export const FETCH_FEATURE = 'fetch_feature';
export const FETCH_CURRENT_EMPLOYEE = 'fetch_current_employee';
export const EDIT_CURRENT_EMPLOYEE = 'edit_current_employee';
export const ADD_NEW_POST = 'add_new_post';
export const GET_ALL_ARTICLES = 'get_all_articles';


