import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import getAllArticles from "../actions/get_all_articles_action";



class Allarticles extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ...props,
            Article: []
        }
    }
    componentWillMount() {
        this.props.getAllArticles();
    }

    componentWillReceiveProps(props) {
        this.setState({
            Article: props.AllArticles
        })
    }
    render() {
        return (
            <section>
                <div>All Articles:</div>
                {
                    this.state.Article.map((artcil, index) => {
                        return (
                            <div className="article-preview" key={index}>
                                <div className="article-meta"><a href="/@abhinavkatiyar"><img src="https://pbs.twimg.com/profile_images/720520705884954624/uv6XS5r2_400x400.jpg" alt="abhinavkatiyar" /></a>
                                    <div className="info"><a className="author" href="/@abhinavkatiyar">abhinavkatiyar</a><span className="date">Mon May 06 2019</span></div>
                                </div>
                                <a className="preview-link" href="/article/demo-ph3-ag6qu">
                                    <h1>{artcil.title}</h1>
                                    <p>{artcil.description}</p>
                                    <span>Read more...</span>
                                    <ul className="tag-list">                                        
                                        
                                    </ul>
                                </a>
                            </div>
                        )
                    })
                }

            </section>
        )
    }
}

export const mapStateToProps = (state) => {
    return {
        AllArticles: state.AllArticles.allarticle
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getAllArticles: getAllArticles
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Allarticles);
