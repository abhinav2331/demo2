import React from "react";

class Notfound extends React.Component {
    render() {
        return (
            <section>
                <h1>404 Not Found!</h1>
            </section>
            )
    }
}

export default Notfound;