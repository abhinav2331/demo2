import React from "react";

class EmployeeMessage extends React.Component {
    render() {
        return (
            <section>
                <section className="app_message">
                    Congratulations!<br />
                    You successfully added Employee.
                </section>
            </section>
        )
    }
}

export default EmployeeMessage;