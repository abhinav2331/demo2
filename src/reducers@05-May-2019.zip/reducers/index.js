import { combineReducers } from "redux";
import getUserListReducers from "./getUsersListReducers.js";
import getRewardsReducers from "./getRewardsReducers.js";
import getEmployeeListReducers from "./getEmployeeListReducers.js";
import getLoginEmployeeReducers from "./getLoginEmployeeReducers";
import getAllArticlesReducers from "./getAllArticlesReducers";

const rootReducer = combineReducers({
    UserList: getUserListReducers,
    RewardList: getRewardsReducers,
    EmployeeList: getEmployeeListReducers,
    EmployeeAuth: getLoginEmployeeReducers,
    AllArticles: getAllArticlesReducers
});

export default rootReducer;
