import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import Inputfield from "./inputField";
import { signupEmployee } from "../actions/login_employee_action";

class Signup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            username:"",
            email: "",
            password: ""
        }        
        this.handleOnChangeSignup = this.handleOnChangeSignup.bind(this);
        this.handleEmployeeSignup = this.handleEmployeeSignup.bind(this);
    }

    handleOnChangeSignup(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }   

    handleEmployeeSignup(e) {
        e.preventDefault();
        debugger;
        const signupdetail = {
            username: this.state.username,
            email: this.state.email,
            password: this.state.password
        };
        this.props.signupEmployee(signupdetail);
    }
    renderError() {
        if (this.props.errorMessage) {
            return (
                <div className="alert alert-danger">
                    <string>Oops! {this.props.errorMessage}</string>
                </div>
            );
        }
    }


    render() {
        return (
            <section className="loginForm">
                <div className="box_header">Sign Up</div>
                <form>
                    <div className="form-group">
                        <label>Username:</label>
                        <Inputfield
                            name="username"
                            inputType="text"
                            content={this.state.username}
                            controlFunc={this.handleOnChangeSignup}
                            placeholder="Username"
                        />
                    </div>
                    <div className="form-group">
                        <label>Email address:</label>
                        <Inputfield
                            name="email"
                            inputType="email"
                            content={this.state.email}
                            controlFunc={this.handleOnChangeSignup}
                            placeholder="Email Id"
                        />
                    </div>
                    <div className="form-group">
                        <label>Password:</label>
                        <Inputfield
                            name="password"
                            inputType="password"
                            content={this.state.password}
                            controlFunc={this.handleOnChangeSignup}
                            placeholder="Password"
                        />
                    </div>
                    {this.renderError()}
                    <button type="submit" onClick={this.handleEmployeeSignup} className="btn btn-primary">Submit</button>
                </form>

            </section>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth,
        errorMessage: state.EmployeeAuth.error
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            signupEmployee: signupEmployee
        },
        dispatch
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(Signup);