import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import Inputfield from "./inputField";
import { loginEmployee } from "../actions/login_employee_action";
import { emailRegex, formValid } from "../constant/form.validation";

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            email: "",
            password: "",
            formErrors: {
                email: "",                
                password: ""
            }
        }
        
        this.handleOnChange = this.handleOnChange.bind(this);
        this.handleEmployeeLogin = this.handleEmployeeLogin.bind(this);
    }

    handleOnChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    handleEmployeeLogin(e) {
        e.preventDefault();
        debugger;
        const logindetail = {
            email: this.state.email,
            password: this.state.password            
        };
        this.props.loginEmployee(logindetail);        
    }
    renderError() {
        if (this.props.errorMessage) {
            return (
                <div className="alert alert-danger">
                    <string>Oops! {this.props.errorMessage}</string>
                </div>
            );
        }
    }


    render() {
        return (
            <section className="loginForm">

                <div className="box_header">Sign In</div>
                <form>
                    <div className="form-group">
                        <label>Email address:</label>                        
                        <Inputfield
                            name="email"
                            inputType="email"
                            content={this.state.email}
                            controlFunc={this.handleOnChange}
                            placeholder="Email Id"
                        />
                    </div>
                    <div className="form-group">
                        <label>Password:</label>                        
                        <Inputfield
                            name="password"
                            inputType="password"
                            content={this.state.password}
                            controlFunc={this.handleOnChange}
                            placeholder="Password"
                        />
                    </div>
                    {this.renderError()}
                    <button type="submit" onClick={this.handleEmployeeLogin} className="btn btn-primary">Submit</button>
                </form>

            </section>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth,
        errorMessage: state.EmployeeAuth.error
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {            
            loginEmployee: loginEmployee
        },
        dispatch
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);