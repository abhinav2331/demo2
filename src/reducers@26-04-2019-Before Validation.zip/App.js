import React from "react";
//import { connect } from "react-redux";
import { BrowserRouter, Router, Route, Switch } from 'react-router-dom';
import History from './history.js';

//import getUsersList from "./actions/get_all_users";
//import getAllRewards from "./actions/get_all_rewards";
//import getEmployeeList from "./actions/get_employee.list";
//import addUser from "./actions/add_user";

//import Allusers from "./components/allUsers";
//import Rewardlist from "./components/rewardList";
//import Allemployee from "./components/allEmployee";
//import Addusermodal from "./components/addUserModal";
import Header from "./components/header";
import Defaulthome from "./components/default.home"
import Login from "./components/login";
import Home from "./components/home";
import Signout from "./components/signout";
import Signup from "./components/signup";
import RequireAuths from "./components/requireAuth";

class App extends React.Component {
    //constructor(props) {
    //    super(props);
    //    this.state = {
    //        openModal: false,
    //        newPersonName: '',
    //        newPersonReason: '',
    //        newPersonReward: '',
    //        newPersonEyes: '',
    //        newPersonNose: '',
    //        newPersonMouth: '',
    //        newPersonSkin: '#CE96FF'
    //    }
    //    this.toggleModal = this.toggleModal.bind(this);
    //    this.handleNewPersonNameChange = this.handleNewPersonNameChange.bind(this);
    //    this.handleNewPersonReasonChange = this.handleNewPersonReasonChange.bind(this);
    //    this.handleNewPersonRewardChange = this.handleNewPersonRewardChange.bind(this);
    //    this.handleNewPersonEyeChange = this.handleNewPersonEyeChange.bind(this);
    //    this.handleNewPersonNoseChange = this.handleNewPersonNoseChange.bind(this);
    //    this.handleNewPersonMouthChange = this.handleNewPersonMouthChange.bind(this);
    //    this.handleSkinChange = this.handleSkinChange.bind(this);
    //    this.handlePersonCreation = this.handlePersonCreation.bind(this);
    //}
    //Toggle Modal
    /*toggleModal() {
        this.setState({
            openModal: !this.state.openModal
        })
    }
    handleNewPersonNameChange(e) {
        this.setState({
            newPersonName: e.target.value
        });
    }
    handleNewPersonReasonChange(e) {
        this.setState({
            newPersonReason: e.target.value
        });
    }
    handleNewPersonRewardChange(e) {
        this.setState({
            newPersonReward: e.target.value
        });
    }
    handleNewPersonEyeChange(e) {
        this.setState({
            newPersonEyes: e.target.value
        });
    }
    handleNewPersonNoseChange(e) {
        this.setState({
            newPersonNose: e.target.value
        });
    }
    handleNewPersonMouthChange(e) {
        this.setState({
            newPersonMouth: e.target.value
        });
    }
    handleSkinChange(e) {
        this.setState({
            newPersonSkin: e.target.value
        });
    }
    handlePersonCreation() {
        const users = {
            name: this.state.newPersonName,
            image: `https://api.adorable.io/avatars/face/eyes${this.state.newPersonEyes}/nose${this.state.newPersonNose}/mouth${this.state.newPersonMouth}/${this.state.newPersonSkin.slice(1)}`,
            reason: this.state.newPersonReason,
            reward: this.state.newPersonReward
        };
        this.props.addUser(users);
    }


    componentDidMount() {
        this.props.getUsersList();
        this.props.getAllRewards();
        this.props.getEmployeeList();
    }*/
    render() {
        return (
            <section className="container">

                <section>
                    <BrowserRouter>
                        <Router history={History}>
                            <section>
                                <Header />
                                <Switch>
                                    <Route exact path="/" component={Defaulthome} />
                                    <Route exact path="/home" component={RequireAuths(Home)} />
                                    <Route exact path="/login" component={Login} />
                                    <Route exact path="/signout" component={Signout} />
                                    <Route exact path="/signup" component={Signup} />
                                </Switch>
                            </section>
                        </Router>
                    </BrowserRouter>
                </section>


                {/* <div className="columns">
                    <div className="column col-md-6">
                        {
                            this.props.UserList.map(user => {
                                return <Allusers key={user.name} user={user} />;
                            })
                        }

                    </div>
                    <div className="column col-md-6">
                        <Rewardlist />
                        <Allemployee />
                    </div>
                </div>
                <Addusermodal
                    createUser={this.handlePersonCreation}
                    addToWantedList={this.handlePersonCreation}
                    skinTone={this.state.newPersonSkin}
                    onSkinChange={this.handleSkinChange}
                    onNoseChange={this.handleNewPersonNoseChange}
                    onMouthChange={this.handleNewPersonMouthChange}
                    onEyeChange={this.handleNewPersonEyeChange}
                    onRewardChange={this.handleNewPersonRewardChange}
                    onReasonChange={this.handleNewPersonReasonChange}
                    onNameChange={this.handleNewPersonNameChange}
                    name={this.state.newPersonName}
                    reason={this.state.newPersonReason}
                    reward={this.state.newPersonReward}
                    eyes={this.state.newPersonEyes}
                    nose={this.state.newPersonNose}
                    mouth={this.state.newPersonMouth}
                    open={this.state.openModal}
                    open={this.state.openModal}
                    close={this.toggleModal}
                />*/}
            </section>
        )
    }
}

/*const mapStateToProps = (state) => {
    return {
        UserList: state.UserList,
        RewardList: state.RewardList,
        EmployeeList: state.EmployeeList,
        EmpStatus: state.EmpStatus
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getUsersList: getUsersList,
            getAllRewards: getAllRewards,
            getEmployeeList: getEmployeeList,
            addUser: addUser
        },
        dispatch
    )
}*/

export default App;
