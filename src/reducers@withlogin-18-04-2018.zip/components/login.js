import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import Inputfield from "./inputField";
import loginEmployee from "../actions/login_employee_action";

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newEmail: "",
            newPassword:""
        }
        this.onChangeLoginEmail = this.onChangeLoginEmail.bind(this);
        this.onChangeLoginPassword = this.onChangeLoginPassword.bind(this);
        this.handleEmployeeLogin = this.handleEmployeeLogin.bind(this);
    }

    onChangeLoginEmail(e) {
        this.setState({
            newEmail: e.target.value
        });
    }
    onChangeLoginPassword(e) {
        this.setState({
            newPassword: e.target.value
        });
    }
    handleEmployeeLogin(e) {
        e.preventDefault();
        debugger;
        const logindetail = {
            email: this.state.newEmail,
            password: this.state.newPassword            
        };
        this.props.loginEmployee(logindetail);        
    }

    render() {
        return (
            <section className="loginForm">

                <div className="box_header">Sign In</div>
                <form>
                    <div className="form-group">
                        <label>Email address:</label>                        
                        <Inputfield
                            name="email"
                            inputType="email"
                            content={this.state.email}
                            controlFunc={this.onChangeLoginEmail}
                            placeholder="Email Id"
                        />
                    </div>
                    <div className="form-group">
                        <label>Password:</label>                        
                        <Inputfield
                            name="password"
                            inputType="password"
                            content={this.state.password}
                            controlFunc={this.onChangeLoginPassword}
                            placeholder="Password"
                        />
                    </div>
                    <button type="submit" onClick={this.handleEmployeeLogin} className="btn btn-primary">Submit</button>
                </form>

            </section>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {            
            loginEmployee: loginEmployee
        },
        dispatch
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);