import { LOGIN_EMPLOYEE } from "./types";
import axios from "axios";

const loginEmployeeAsync = (logindetail) => {    
    return {
        type: LOGIN_EMPLOYEE,
        payload: {
            email: logindetail.email,
            password: logindetail.password            
        }
    }
}


const loginEmployee = ({ email, password }) => {
    return dispatch => {
        debugger;
        return axios.post("https://conduit.productionready.io/api/users/login", { "user": { email, password } })
            .then((response) => {                
                console.log(response.data.user.token);
                console.log(response.data);
                dispatch(loginEmployeeAsync({ email, password }));
            })
            .catch((error) => {
                console.log(error);
                throw (error);
            });
    }
}

export default loginEmployee;

