import { LOGIN_EMPLOYEE } from "../actions/types";

const getLoginEmployeeReducers = (state = [], action) => {
    switch (action.type) {
        case LOGIN_EMPLOYEE:
            return action.payload;
        default:
            return state;
    }
    
}

export default getLoginEmployeeReducers;

