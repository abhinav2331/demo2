import React from "react";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import Inputfield from "./inputField";
import Textarea from "./textarea";
import { addNewPost } from "../actions/login_employee_action";

class Addnewpost extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            title: "",
            description: "",
            body: "",
            tagList: ""            
        }
        this.handleOnChange = this.handleOnChange.bind(this);
        this.handleaddNewPost = this.handleaddNewPost.bind(this);
    }
    
    handleOnChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
    }
    handleaddNewPost(e) {        
        e.preventDefault();
        const addPost = {
            title: this.state.title,
            description: this.state.description,
            body: this.state.body,
            tagList: this.state.tagList
        };
        this.props.addNewPost(addPost);
    }
    render() {
        return (
            <section className="article_section">
                <h3>Add new post:</h3>
                <form>
                    <div className="form-group">
                        <label className="form-label">Title:</label>
                        <Inputfield
                            className="form-control"
                            name="title"
                            inputType="text"
                            content={this.state.title}
                            controlFunc={this.handleOnChange}
                            placeholder="Title"
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Description:</label>
                        <Inputfield
                            className="form-control"
                            name="description"
                            inputType="text"
                            content={this.state.description}
                            controlFunc={this.handleOnChange}
                            placeholder="Description"
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Article Body:</label>
                        <Textarea
                            className="form-control"
                            name="body"
                            content={this.state.body}
                            controlFunc={this.handleOnChange}
                            placeholder="Article Body"
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Tags:</label>
                        <Inputfield
                            className="form-control"
                            name="tagList"
                            inputType="text"
                            content={this.state.tagList}
                            controlFunc={this.handleOnChange}
                            placeholder="Tags"
                        />
                    </div>                    
                    <button onClick={this.handleaddNewPost} className="btn btn-primary">Create Article</button>
                </form>

 

            </section>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth.addnewpost
    }
}


const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            addNewPost: addNewPost
        },
        dispatch
    )
}




export default connect(mapStateToProps, mapDispatchToProps)(Addnewpost);