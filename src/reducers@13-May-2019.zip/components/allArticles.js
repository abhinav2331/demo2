import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import moment from "moment";
import { Link } from "react-router-dom";


import getAllArticles from "../actions/get_all_articles_action";
import { getAllTags, getArticleByTag, add_favorite, remove_favorite } from "../actions/articles_action";
import Fabicon from "./fabIcon";



class Allarticles extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ...props,
            Article: [],
            Tag: [],
            SelectedTag:"",
            Tagarticle:[]
        }
        this.onClickArticleByTag = this.onClickArticleByTag.bind(this);
        this.onClickClearSelectTag = this.onClickClearSelectTag.bind(this);
        //this.favoriteHandleClick = this.favoriteHandleClick.bind(this);
    }
    componentWillMount() {
        this.props.getAllArticles();
        this.props.getAllTags();
    }

    componentWillReceiveProps(props) {
        this.setState({
            Article: props.AllArticles,
            Tag: props.ArticleSection.tags,
            Tagarticle: props.ArticleByTag
        })
    }

    onClickArticleByTag(index, tagList) {
        debugger;        
        this.props.getArticleByTag(tagList);
        this.setState({
            SelectedTag: tagList
        })
    }
    onClickClearSelectTag() {
        this.setState({
            SelectedTag: ""
        })
    }
    // favoriteHandleClick(articleitem) {        
    //     debugger;        
    //     if (articleitem.favorited) {
    //         this.props.remove_favorite(articleitem.slug);
    //     } else {
    //         this.props.add_favorite(articleitem.slug);
    //     }        
    // };

    render() {
        return (
            <section className="content">

                <div style={{ marginBottom: "10px" }}>
                    <button onClick={this.onClickClearSelectTag} className="btn btn-primary">All Articles</button>
                    {
                        this.state.SelectedTag !== "" ? <button style={{marginLeft:"10px"}} className="btn btn-primary"># {this.state.SelectedTag}</button> : ""
                    }

                    
                </div>
                <div className="row">
                    <div className="col-md-9">                        

                        {/*Start This is for the Article By Tags*/}

                        {
                            this.state.SelectedTag === "" ?
                                <div>{this.state.Article.map((articleitem, index) => {
                                    const thedate = moment(articleitem.createdAt).format("DD-MM-YYYY");
                                    return (
                                        <div className="article-preview" key={index}>
                                            <div className="article-meta">
                                                <Fabicon 
                                                    articleData={articleitem}
                                                />
                                                {/*<div className="fab" onClick={() => this.favoriteHandleClick(articleitem)}>{articleitem.favoritesCount}</div>  */}                                              
                                                <a href="/@abhinavkatiyar">
                                                    {
                                                        articleitem.author.image === "" ? <img src="http://chittagongit.com/images/dummy-icon/dummy-icon-7.jpg" alt="" />
                                                            : <img src={articleitem.author.image} alt="user" />
                                                    }
                                                </a>
                                                <div className="info"><a className="author" href="/@abhinavkatiyar">{articleitem.author.username}</a><span className="date">{thedate}</span></div>
                                            </div>
                                            <Link className="preview-link" to={`/article/${articleitem.slug}`}>
                                                <h1>{articleitem.title}</h1>
                                                <p>{articleitem.body}</p>
                                                <span>Read more...</span>
                                                <ul className="tag-list">
                                                    {articleitem.tagList.map((tagitem, index) => {
                                                        return (
                                                            <li key={index}>
                                                                {tagitem}
                                                            </li>
                                                        )
                                                    })}
                                                </ul>
                                            </Link>
                                        </div>  
                                    )
                                })}</div>

                                : <div>{
                                    this.state.Tagarticle.map((tagarticleitem, index) => {
                                        const thedate = moment(tagarticleitem.createdAt).format("DD-MM-YYYY");
                                        return (
                                            <div className="article-preview" key={index}>
                                                <div className="article-meta">
                                                    <a href="/@abhinavkatiyar">
                                                        {
                                                            tagarticleitem.author.image === "" ? <img src="http://chittagongit.com/images/dummy-icon/dummy-icon-7.jpg" alt="" />
                                                                : <img src={tagarticleitem.author.image} alt="user" />
                                                        }
                                                    </a>
                                                    <div className="info"><a className="author" href="/@abhinavkatiyar">{tagarticleitem.author.username}</a><span className="date">{thedate}</span></div>
                                                </div>
                                                <a className="preview-link" href="/article/demo-ph3-ag6qu">
                                                    <h1>{tagarticleitem.title}</h1>
                                                    <p>{tagarticleitem.body}</p>
                                                    <span>Read more...</span>
                                                    <ul className="tag-list">
                                                        {tagarticleitem.tagList.map((tagitemnew, index) => {
                                                            return (
                                                                <li key={index}>
                                                                    {tagitemnew}
                                                                </li>
                                                            )
                                                        })}
                                                    </ul>
                                                </a>
                                            </div>
                                        )
                                    })
                                }</div>
                        }

                        {/*End This is for the Article By Tags*/}

                    </div>
                    <div className="col-md-3">
                        {
                            this.state.Tag.map((tagList, index) => {
                                return (
                                    <span className="tags" key={index}>
                                        <a onClick={() => this.onClickArticleByTag(index, tagList)}>{tagList}</a>
                                    </span>
                                    )
                            })
                        }
                    </div>
                </div>
                
            </section>
        )
    }
}

export const mapStateToProps = (state) => {
    return {
        AllArticles: state.AllArticles.allarticle,
        ArticleSection: state.ArticleSection.alltags,
        ArticleByTag: state.ArticleByTag.articlebytag
        //ArticleByTag: state.ArticleByTag.data
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getAllArticles: getAllArticles,
            getAllTags: getAllTags,
            getArticleByTag: getArticleByTag
            //add_favorite: add_favorite,
            //remove_favorite: remove_favorite
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Allarticles);
