import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import moment from "moment";

import { getArticleBySlug } from "../actions/articles_action";

class Articledetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            slug: "",
            Byslugarticle: [],
            Author:[]
        }
    }
    componentWillMount() {
        this.setState({
            slug: this.props.location.pathname.slice(9)
        })
    }
    componentDidMount() {
        //debugger;       
        const clickedslug = this.state.slug;
        this.props.getArticleBySlug(clickedslug);
    }

    componentWillReceiveProps(props) {
        this.setState({
            Byslugarticle: props.ArticleByTag,
            Author: props.ArticleByTag.author
        })
    }

    render() {
        const thedate = moment(this.state.Byslugarticle.createdAt).format("DD-MM-YYYY");
        return (
            <section>
                <div className="banner">                       
                    <h1>Article Title: {this.state.Byslugarticle.title}</h1>
                    
                    <div className="article-meta">
                        <a href="/@abhinavkatiyar">
                            {
                                this.state.Author.image === "" ? <img src="http://chittagongit.com/images/dummy-icon/dummy-icon-7.jpg" alt="" />
                                    : <img src={this.state.Author.image} alt="user" />
                            }
                        </a>
                        <div className="info"><a className="author" href="/@abhinavkatiyar">{this.state.Author.username}</a><span className="date">{thedate}</span></div>
                        <span>
                            <a  style={{marginRight:"20px"}} className="btn btn-outline-secondary btn-sm">
                            <i className="ion-edit"></i> Edit Article</a>
                            <button className="btn btn-outline-danger btn-sm">
                            <i className="ion-trash-a"></i> Delete Article</button>
                        </span>
                    
                    </div>
                    
                </div>

                <div>
                    Article Body:{this.state.Byslugarticle.body}<br/>
                    Article Description:{this.state.Byslugarticle.description}
                </div>

            </section>
        )
    }
}


export const mapStateToProps = (state) => {
    return {
        ArticleByTag: state.ArticleByTag.articlebyslug
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getArticleBySlug: getArticleBySlug
        },
        dispatch
    )
}



export default connect(mapStateToProps, mapDispatchToProps)(Articledetail);