import axios from "axios";
import { GET_ALL_TAGS, GET_ARTICLE_BY_TAG, GET_ARTICLE_BY_SLUG, GET_ARTICLE_BY_AUTHOR, ADD_FAVORITE, REMOVE_FAVORITE } from './types';

import { AUTH_URI } from "../app.uri";


export const getAllTags = () => {
    //debugger;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/tags`)
            .then(response => {
                console.log(response.data);
                dispatch({
                    type: GET_ALL_TAGS,
                    payload: response.data
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleByTag = (tagList) => {
    //debugger;
    const uri_tag = tagList;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles?tag=${uri_tag}`)
            .then(response => {
                //console.log("--------");
                //console.log(response.data.articles);
                dispatch({
                    type: GET_ARTICLE_BY_TAG,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleBySlug = (clickedslug) => {
    //debugger;
    const slug_uri = clickedslug;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles/${slug_uri}`)
            .then(response => {
                //console.log("--------");
                //console.log(response.data);
                dispatch({
                    type: GET_ARTICLE_BY_SLUG,
                    payload: response.data.article
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleByAuthor = (username) => {    
    return (dispatch) => {
        //debugger;
        const author_uri = username;
        axios.get(`${AUTH_URI}/articles?author=${author_uri}`)
            .then(response => {
                console.log("---By Author@");
                console.log(response.data.articles);
                dispatch({
                    type: GET_ARTICLE_BY_AUTHOR,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const add_favorite = (slug) => {
    return (dispatch) => {
        debugger;
        const slug_uri = slug;        
        axios({
            method: 'post',
            url: `${AUTH_URI}/articles/${slug_uri}/favorite`,
            //data: JSON.stringify(currentemployees),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: ADD_FAVORITE });
            console.log("Plus" + response.data);
        }).catch(error => {
            console.log("Post Error : " + error);
        });
    };
};
export const remove_favorite = (slug) => {
    return (dispatch) => {
        //debugger;
        const slug_uri = slug;        
        axios({
            method: 'delete',
            url: `${AUTH_URI}/articles/${slug_uri}/favorite`,
            //data: JSON.stringify(currentemployees),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: REMOVE_FAVORITE });
            console.log("Plus" + response.data);
        }).catch(error => {
            console.log("Post Error : " + error);
        });
    };
};



