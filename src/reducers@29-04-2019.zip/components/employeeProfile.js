import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { fetchCurrentEmployee } from "../actions/login_employee_action";

class Currentemployee extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            id: "",
            email: "",
            createdAt: "",
            updatedAt: "",
            username: "",
            bio: "",
            image: "",
            token:""
        }
    }

    componentWillMount() {        
        this.props.fetchCurrentEmployee();    
        this.setState({
            //id: this.props.EmployeeAuth.id,
            //email: this.props.EmployeeAuth.email,
            //createdAt: this.props.EmployeeAuth.createdAt,
            //updatedAt: this.props.EmployeeAuth.updatedAt,
            //username: this.props.EmployeeAuth.username,
            //bio: this.props.EmployeeAuth.bio,
            //image: this.props.EmployeeAuth.image,
            //token: this.props.EmployeeAuth.token
        })
    }
    
    render() {
        const EmployeeAuth = this.props;
        //debugger;
        //console.log("Hello-:" + EmployeeAuth.username);
        return (
            <section>
                <div>Employee Profile</div>                      
                                
            </section>
        )
    }
}

const mapStateToProps = (state) => {
    return { EmployeeAuth: state.EmployeeAuth.currentEmployee }
    //return { EmployeeAuth: state.EmployeeAuth}
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            fetchCurrentEmployee: fetchCurrentEmployee            
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Currentemployee);