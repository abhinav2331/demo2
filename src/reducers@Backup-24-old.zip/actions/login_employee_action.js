import axios from "axios";
import History from "../constant/history.js";
//import { LOGIN_EMPLOYEE } from "./types";
import { AUTH_URI } from "../constant/uri.constants";
//import { AUTH_USER, UNAUTH_USER, AUTH_ERROR, FETCH_FEATURE } from "../constant/auth.constants";
import { GET_ERRORS, SET_CURRENT_USER } from "./types";
import setAuthToken from "../set.auth.token";

export const setCurrentUser = decoded => {
    return {
        type: SET_CURRENT_USER,
        payload: decoded
    }
}

export const loginEmployee = (user) => dispatch => {
    debugger;
    axios.post(`${AUTH_URI}/users/login`, { "user": user })
        .then(response => {
            const { token } = response.data;
            console.log(response.data);
            localStorage.setItem('token', response.data.user.token);
            setAuthToken(token);
            const decoded = response.data.user.token;
            dispatch(setCurrentUser(decoded));
            History.push('/');
        })
        .catch(error => {
            dispatch({
                type: GET_ERRORS,
                payload: error.response
            });
        });
}

export const logoutUser = (History) => dispatch => {
    localStorage.removeItem('token');
    setAuthToken(false);
    dispatch(setCurrentUser({}));
    History.push('/login');
}

