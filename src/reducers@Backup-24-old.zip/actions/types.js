export const GET_USERS_LIST = "get_users_list";
export const GET_ALL_REWARDS = "get_all_rewards";
export const GET_EMPLOYEE_LIST = "get_employee_list";
export const UPDATE_REASON = "update_reason";
export const DELETE_USER = "delete_user";
export const ADD_USER = "add_user";
export const ADD_EMPLOYEE = "add_employee";
export const EDIT_EMPLOYEE = "edit_employee";
export const DELETE_EMPLOYEE = "delete_employee";
export const EMP_ADD_RESPONSE = "emp_add_response";
export const LOGIN_EMPLOYEE = "login_employee";

export const GET_ERRORS = 'GET_ERRORS';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';

