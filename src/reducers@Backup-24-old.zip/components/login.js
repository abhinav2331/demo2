import React from "react";
import PropTypes from 'prop-types';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import classnames from 'classnames';

import Inputfield from "./inputField";
import { loginEmployee } from "../actions/login_employee_action";

class Login extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newEmail: "",
            newPassword: "",
            email: "",
            password: "",
            GetErrors: {}
        }
        this.handleEmployeeLogin = this.handleEmployeeLogin.bind(this); 
        this.handleInputChange = this.handleInputChange.bind(this);
    }


    handleInputChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    handleEmployeeLogin(e) {
        e.preventDefault();
        const user = {
            email: this.state.email,
            password: this.state.password
        }
        this.props.loginEmployee(user);
    }

    componentDidMount() {
        if (this.props.EmployeeAuth.isAuthenticated) {
            this.props.History.push('/');
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.EmployeeAuth.isAuthenticated) {
            this.props.History.push('/')
        }
        if (nextProps.GetErrors) {
            this.setState({
                GetErrors: nextProps.GetErrors
            });
        }
    }

    render() {
        const { GetErrors } = this.state;
        return (
            <section className="loginForm">

                <div className="box_header">Sign In</div>
                <form>
                    <div className="form-group">
                        <label>Email address:</label>                        
                        <Inputfield
                            name="email"
                            inputType="email"
                            className={classnames('form-control form-control-lg', {
                                'is-invalid': GetErrors
                            })}
                            content={this.state.email}
                            controlFunc={this.handleInputChange}
                            placeholder="Email Id"
                        />
                        {GetErrors.email && (<div>{GetErrors.errors}</div>)}
                    </div>
                    <div className="form-group">
                        <label>Password:</label>                        
                        <Inputfield
                            name="password"
                            inputType="password"
                            className={classnames('form-control form-control-lg', {
                                'is-invalid': GetErrors
                            })} 
                            content={this.state.password}
                            controlFunc={this.handleInputChange}
                            placeholder="Password"
                        />
                        {GetErrors.password && (<div>{GetErrors.errors}</div>)}
                    </div>
                    
                    <button type="submit" onClick={this.handleEmployeeLogin} className="btn btn-primary">Submit</button>
                </form>

            </section>
        )
    }
}


Login.propTypes = {
    loginEmployee: PropTypes.func.isRequired,
    EmployeeAuth: PropTypes.object.isRequired,
    GetErrors: PropTypes.object.isRequired
}

const mapStateToProps = (state) => {
    return {
        EmployeeAuth: state.EmployeeAuth,
        GetErrors: state.GetErrors        
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {            
            loginEmployee: loginEmployee            
        },
        dispatch
    )
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);