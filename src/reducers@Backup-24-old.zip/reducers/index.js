import { combineReducers } from "redux";
import getUserListReducers from "./getUsersListReducers.js";
import getRewardsReducers from "./getRewardsReducers.js";
import getEmployeeListReducers from "./getEmployeeListReducers.js";
import getLoginEmployeeReducers from "./getLoginEmployeeReducers";
import getErrors from "./errorReducer";

const rootReducer = combineReducers({
    UserList: getUserListReducers,
    RewardList: getRewardsReducers,
    EmployeeList: getEmployeeListReducers,
    EmployeeAuth: getLoginEmployeeReducers,
    GetErrors: getErrors
});

export default rootReducer;
