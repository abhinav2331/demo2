import React from "react";

class Defaulthome extends React.Component {
    render() {
        return (
            <section className="default_section">
                Welcome to the Web API. <br/>The core concept behind the Redux.
            </section>
            )
    }
}



export default Defaulthome;