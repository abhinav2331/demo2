import React from "react";
import { connect } from 'react-redux';
import { bindActionCreators } from "redux";
import { fetchCurrentEmployee } from "../actions/login_employee_action";

class Currentemployee extends React.Component {

    componentWillMount() {
        this.props.fetchCurrentEmployee();
    }

    render() {
        debugger;
        console.log("Hello:"+this.props.EmployeeAuth);
        return (
            
            <section>
                <div>Employee Profile</div>
                <div>                   
                   
                </div>
            </section>
        )
    }
}

const mapStateToProps = (state) => {
    return { EmployeeAuth: state.EmployeeAuth.currentEmployee }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            fetchCurrentEmployee: fetchCurrentEmployee
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Currentemployee);