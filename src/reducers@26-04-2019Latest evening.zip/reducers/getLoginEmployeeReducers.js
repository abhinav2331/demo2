import { AUTH_USER, UNAUTH_USER, AUTH_ERROR, FETCH_CURRENT_EMPLOYEE } from '../actions/types';

const getLoginEmployeeReducers = (state = {}, action) => {

    switch (action.type) {
        case AUTH_USER:
            return { ...state, error: '', authenticated: true }
        case UNAUTH_USER:
            return { ...state, authenticated: false }
        case AUTH_ERROR:
            return { ...state, error: action.payload }
        case FETCH_CURRENT_EMPLOYEE:
            return { ...state, currentEmployee: action.payload }
        default:
            return state;
    }
};


export default getLoginEmployeeReducers;



