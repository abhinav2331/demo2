import axios from "axios";
import { GET_ALL_TAGS, GET_ARTICLE_BY_TAG, GET_ARTICLE_BY_SLUG, GET_ARTICLE_BY_AUTHOR, ADD_FAVORITE, REMOVE_FAVORITE, EDIT_ARTICLEDATA, DELETE_ARTICLEDATA, CREATE_COMMENT, GET_COMMENT } from './types';

import { AUTH_URI } from "../app.uri";
import History from '../history.js';


export const getAllTags = () => {
    //debugger;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/tags`)
            .then(response => {
                //console.log(response.data);
                dispatch({
                    type: GET_ALL_TAGS,
                    payload: response.data
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleByTag = (tagList) => {
    //debugger;
    const uri_tag = tagList;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles?tag=${uri_tag}`)
            .then(response => {
                //console.log("--------");
                //console.log(response.data.articles);
                dispatch({
                    type: GET_ARTICLE_BY_TAG,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleBySlug = (clickedslug) => {
    //debugger;
    const slug_uri = clickedslug;
    return (dispatch) => {
        axios.get(`${AUTH_URI}/articles/${slug_uri}`)
            .then(response => {
                //console.log("--------");
                //console.log(response.data);
                dispatch({
                    type: GET_ARTICLE_BY_SLUG,
                    payload: response.data.article
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const getArticleByAuthor = (username) => {    
    return (dispatch) => {
        //debugger;
        const author_uri = username;
        axios.get(`${AUTH_URI}/articles?author=${author_uri}`)
            .then(response => {
                console.log("---By Author@");
                //console.log(response.data.articles);
                dispatch({
                    type: GET_ARTICLE_BY_AUTHOR,
                    payload: response.data.articles
                });
            }).catch(error => {
                console.log(error);
            });
    };
};

export const add_favorite = (slug) => {
    return (dispatch) => {
        debugger;
        const slug_uri = slug;        
        axios({
            method: 'post',
            url: `${AUTH_URI}/articles/${slug_uri}/favorite`,
            //data: JSON.stringify(currentemployees),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: ADD_FAVORITE });
            //console.log("Plus" + response.data);
        }).catch(error => {
            console.log("Post Error : " + error);
        });
    };
};
export const remove_favorite = (slug) => {
    return (dispatch) => {
        //debugger;
        const slug_uri = slug;        
        axios({
            method: 'delete',
            url: `${AUTH_URI}/articles/${slug_uri}/favorite`,
            //data: JSON.stringify(currentemployees),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: REMOVE_FAVORITE });
            //console.log("Plus" + response.data);
        }).catch(error => {
            console.log("Post Error : " + error);
        });
    };
};

export const editArticleData = (editData) => {
    //debugger;  
    const article_slug = editData.slug
    return (dispatch) => {
        axios({
            method: 'put',
            url: `${AUTH_URI}/articles/${article_slug}`,
            data: JSON.stringify(editData),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: EDIT_ARTICLEDATA });
            //console.log("Plus" + response.data.article);
           
        }).catch(error => {
            console.log("Post Error : " + error);
        });
    }

};

export const deleteArticleData = (deleteData) => {
    //debugger;
    const article_slug = deleteData.slug
    return (dispatch) => {
        axios({
            method: 'delete',
            url: `${AUTH_URI}/articles/${article_slug}`,
            //data: JSON.stringify(editData),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: DELETE_ARTICLEDATA });
            //console.log(response.data);
            // - redirect to the route '/feature'
            History.push('/employeeprofile');

        }).catch(error => {
            console.log("Post Error : " + error);
        });
    }

};

export const createComments = (commentdata) => {
    //debugger;
    const article_slug = commentdata.slug
    return (dispatch) => {
        axios({
            method: 'post',
            url: `${AUTH_URI}/articles/${article_slug}/comments`,
            data: JSON.stringify({ "body": commentdata.comment}),
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache',
                'authorization': "Token " + localStorage.getItem("token")
            }
        }).then(response => {
            dispatch({ type: CREATE_COMMENT });
            //console.log(response.data);                    

        }).catch(error => {
            console.log("Post Error : " + error);
        });
    }

};

export const getComments = (commentslug) => {
    //debugger;
    const article_slug = commentslug.slug
    return (dispatch) => {
        axios({
            method: 'get',
            url: `${AUTH_URI}/articles/${article_slug}/comments`
            //data: JSON.stringify({ "body": commentdata.comment }),
            //headers: {
            //    'Content-Type': 'application/json',
            //    'Cache-Control': 'no-cache',
            //    'authorization': "Token " + localStorage.getItem("token")
            //}
        }).then(response => {
            dispatch({                
                type: GET_COMMENT,
                payload: response.data.comments
            });
            //console.log(response.data.comments);

        }).catch(error => {
            console.log("Post Error : " + error);
        });
    }

};




