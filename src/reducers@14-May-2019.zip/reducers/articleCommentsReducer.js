import { GET_COMMENT } from '../actions/types';

const getCommentReducers = (state = {}, action) => {

    switch (action.type) {        

        case GET_COMMENT:
            return { ...state, data: action.payload }

        default:
            return state;
    }
};


export default getCommentReducers;



