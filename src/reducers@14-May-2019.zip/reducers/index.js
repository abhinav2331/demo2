import { combineReducers } from "redux";
import getUserListReducers from "./getUsersListReducers.js";
import getRewardsReducers from "./getRewardsReducers.js";
import getEmployeeListReducers from "./getEmployeeListReducers.js";
import getLoginEmployeeReducers from "./getLoginEmployeeReducers";
import getAllArticlesReducers from "./getAllArticlesReducers";
import getAllTagsReducers from "./getAllTagsReducers";
import getArticleByTagReducers from "./articleReducers";
import getCommentReducers from "./articleCommentsReducer";

const rootReducer = combineReducers({
    UserList: getUserListReducers,
    RewardList: getRewardsReducers,
    EmployeeList: getEmployeeListReducers,
    EmployeeAuth: getLoginEmployeeReducers,
    AllArticles: getAllArticlesReducers,
    ArticleSection: getAllTagsReducers,
    ArticleByTag: getArticleByTagReducers,
    ArticleComment: getCommentReducers
});

export default rootReducer;
