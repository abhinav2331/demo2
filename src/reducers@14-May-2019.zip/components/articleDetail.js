import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import moment from "moment";

import { getArticleBySlug, deleteArticleData } from "../actions/articles_action";
import Editarticlemodal from "./editArticleModal";
import Addcomment from "./addComment";
import Commentlist from "./commentList";


class Articledetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            slug: "",
            Byslugarticle: [],
            Author: [],
            editArticleModal: false,
            currentuser: ""
        }
        this.toggleEditArticleModal = this.toggleEditArticleModal.bind(this);
        this.closeEditArticleModal = this.closeEditArticleModal.bind(this);
        this.handleDeleteArticleModal = this.handleDeleteArticleModal.bind(this);
    }

    toggleEditArticleModal() {
        this.setState({
            editArticleModal: !this.state.editArticleModal
        });
    }

    closeEditArticleModal() {
        this.setState({
            editArticleModal: !this.state.editArticleModal
        })
    }

    componentWillMount() {
        this.setState({
            slug: this.props.location.pathname.slice(9)
        })
    }
    componentDidMount() {
        const clickedslug = this.state.slug;
        this.props.getArticleBySlug(clickedslug);
    }

    componentWillReceiveProps(props) {
        this.setState({
            Byslugarticle: props.ArticleByTag,
            Author: props.ArticleByTag.author
        })
    }

    handleDeleteArticleModal(e) {
        debugger;
        e.preventDefault();
        const deleteData = {
            slug: this.state.slug
        };
        this.props.deleteArticleData(deleteData);
    }

    render() {
        const user = localStorage.getItem("crntuser");
        const thedate = moment(this.state.Byslugarticle.createdAt).format("DD-MM-YYYY");
        return (
            <section>
                <div className="banner">
                    <h1>Article Title: {this.state.Byslugarticle.title}</h1>

                    <div className="article-meta">
                        <a href="/@abhinavkatiyar">
                            {
                                this.state.Author.image === "" ? <img src="http://chittagongit.com/images/dummy-icon/dummy-icon-7.jpg" alt="" />
                                    : <img src={this.state.Author.image} alt="user" />
                            }
                        </a>
                        <div className="info"><a className="author" href="/@abhinavkatiyar">{this.state.Author.username}</a><span className="date">{thedate}</span></div>
                        {
                            user !== null ?
                                <span>
                                    <a style={{ marginRight: "20px" }} onClick={this.toggleEditArticleModal} className="btn btn-outline-secondary btn-sm">
                                        <i className="ion-edit"></i> Edit Article</a>

                                    <button onClick={this.handleDeleteArticleModal} className="btn btn-outline-danger btn-sm">
                                        <i className="ion-trash-a"></i> Delete Article</button>
                                </span>
                                : ""
                        }



                    </div>

                </div>

                <div>
                    Article Body:{this.state.Byslugarticle.body}<br />
                    Article Description:{this.state.Byslugarticle.description}
                </div>

                <hr />
                <div className="comment_panel">
                    <Addcomment
                        slug={this.state.slug}
                    />
                    <Commentlist
                        slug={this.state.slug}
                    />
                </div>

                <Editarticlemodal
                    open={this.state.editArticleModal}
                    close={this.closeEditArticleModal}
                    articledata={this.state.Byslugarticle}
                />

            </section>
        )
    }
}


export const mapStateToProps = (state) => {
    return {
        ArticleByTag: state.ArticleByTag.articlebyslug
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getArticleBySlug: getArticleBySlug,
            deleteArticleData: deleteArticleData
        },
        dispatch
    )
}



export default connect(mapStateToProps, mapDispatchToProps)(Articledetail);