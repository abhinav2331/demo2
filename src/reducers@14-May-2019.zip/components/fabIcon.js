import React from "react";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import getAllArticles from "../actions/get_all_articles_action";
import { add_favorite, remove_favorite } from "../actions/articles_action";

class Fabicon extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            ...props,            
            Tagarticle:[]
        }        
        this.favoriteHandleClick = this.favoriteHandleClick.bind(this);
    }    
    componentWillReceiveProps(props) {
        this.setState({
            //Article: props.AllArticles,
            //Tag: props.ArticleSection.tags,
            //Tagarticle: props.ArticleByTag
        })
    }   
    
    favoriteHandleClick(articleData) {        
        debugger;        
        if (articleData.favorited) {
            this.props.remove_favorite(articleData.slug);
        } else {
            this.props.add_favorite(articleData.slug);
        }   
        this.props.getAllArticles();     
    };

    render() {
        const articleData = this.props.articleData;
        return (
            <div className="fab" onClick={() => this.favoriteHandleClick(articleData)}>
            <i className="fa fa-heart"></i>{articleData.favoritesCount}</div>                                             
        )
    }
}

export const mapStateToProps = (state) => {
    return {        
        ArticleByTag: state.ArticleByTag.data,
        AllArticles: state.AllArticles.allarticle
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {            
            add_favorite: add_favorite,
            remove_favorite: remove_favorite,
            getAllArticles: getAllArticles
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Fabicon);