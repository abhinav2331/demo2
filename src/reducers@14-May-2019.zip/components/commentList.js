import React from "react";
import moment from "moment";

import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { getComments } from "../actions/articles_action";

class Commentlist extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            ...props,
            slug: "",
            Comment: []
        }
    }

    componentDidMount() {
        debugger;
        const commentslug = {
            slug: this.props.slug
        }
        this.props.getComments(commentslug);
    }
    componentWillReceiveProps(props) {
        this.setState({
            Comment: props.ArticleComment
        })
    }

    render() {   
        
        return (
            <section>
                {
                    this.state.Comment.map((item, index) => {
                        const thedate = moment(item.createdAt).format("DD-MM-YYYY");
                        return (
                            <div className="card" key={index}>
                                <div className="card-block">
                                    {item.body}
                                </div>
                                <div className="card-footer">
                                    <a className="comment-author" href="">
                                        <img src={item.author.image} className="comment-author-img" alt={item.author.username} />
                                    </a>
                                    <span>{item.author.username} - ({thedate})</span>
                                </div>
                            </div>
                        )
                    })
                }


            </section>
        )
    }
}

export const mapStateToProps = (state) => {
    return {
        ArticleComment: state.ArticleComment.data
    }
}
const mapDispatchToProps = (dispatch) => {
    return bindActionCreators(
        {
            getComments: getComments
        },
        dispatch
    )
}


export default connect(mapStateToProps, mapDispatchToProps)(Commentlist);
