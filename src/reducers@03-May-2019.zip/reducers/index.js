import { combineReducers } from "redux";
import getUserListReducers from "./getUsersListReducers.js";
import getRewardsReducers from "./getRewardsReducers.js";
import getEmployeeListReducers from "./getEmployeeListReducers.js";
import getLoginEmployeeReducers from "./getLoginEmployeeReducers";

const rootReducer = combineReducers({
    UserList: getUserListReducers,
    RewardList: getRewardsReducers,
    EmployeeList: getEmployeeListReducers,
    EmployeeAuth: getLoginEmployeeReducers
});

export default rootReducer;
