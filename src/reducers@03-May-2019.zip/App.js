import React from "react";
//import { connect } from "react-redux";
import { BrowserRouter, Router, Route, Switch } from 'react-router-dom';
import History from './history.js';

import Header from "./components/header";
import Defaulthome from "./components/default.home"
import Login from "./components/login";
import Home from "./components/home";
import Signout from "./components/signout";
import Signup from "./components/signup";
import Currentemployee from "./components/employeeProfile";
import RequireAuths from "./components/requireAuth";
import Addnewpost from "./components/addNewPost";

class App extends React.Component {
    
    render() {
        return (
            <section className="container">

                <section>
                    <BrowserRouter>
                        <Router history={History}>
                            <section>
                                <Header />
                                <Switch>
                                    <Route exact path="/" component={Defaulthome} />
                                    <Route exact path="/home" component={RequireAuths(Home)} />
                                    <Route exact path="/login" component={Login} />
                                    <Route exact path="/signout" component={Signout} />
                                    <Route exact path="/signup" component={Signup} />
                                    <Route exact path="/employeeprofile" component={RequireAuths(Currentemployee)} />
                                    <Route exact path="/addnewpost" component={RequireAuths(Addnewpost)} />
                                </Switch>
                            </section>
                        </Router>
                    </BrowserRouter>
                </section>
            </section>
        )
    }
}

export default App;
